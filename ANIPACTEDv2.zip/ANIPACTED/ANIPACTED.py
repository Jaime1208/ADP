from flask import Flask,render_template

ANIPACTED = Flask(__name__)


@ANIPACTED.route('/')
def CShome():
    return render_template('CShome.html')

@ANIPACTED.route('/CS-Login')
def CSlogin():
    return render_template('CS-Login.html')

@ANIPACTED.route('/CS-Register')
def CSregister():
    return render_template('CS-Register.html')

@ANIPACTED.route('/CS-Profile')
def CSprofile():
    return render_template('CS-Profile.html')

@ANIPACTED.route('/CS-Logout')
def CSlogout():
    return render_template('CS-Logout.html')

@ANIPACTED.route('/CS-Help')
def CShelp():
    return render_template('CS-Help.html')

@ANIPACTED.route('/STFhome')
def STFhome():
    return render_template('STFhome.html')

@ANIPACTED.route('/STF-Login')
def STFlogin():
    return render_template('STF-Login.html')

@ANIPACTED.route('/STF-Profile')
def STFprofile():
    return render_template('STF-Profile.html')

@ANIPACTED.route('/STF-Logout')
def STFlogout():
    return render_template('STF-Logout.html')

if __name__ == '__main__':
    ANIPACTED.run()
