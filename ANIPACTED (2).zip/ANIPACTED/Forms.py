from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators, TelField
from wtforms.fields import EmailField, DateField, SubmitField

class CreateStaffForm(Form):
    first_name = StringField('First Name', [validators.length(min=1, max=150), validators.DataRequired()])
    last_name = StringField('Last Name', [validators.length(min=1, max=150), validators.DataRequired()])
    email = EmailField('Email', [validators.DataRequired(),validators.Email()])
    phone_number = TelField('Phone Number',[validators.DataRequired(),validators.length(min=7, max=15)])
    staff_status = SelectField('Staff Status', [validators.DataRequired()], choices=[('A', 'Active'), ('R', 'Resigned'),('L', 'On-Leave')],default='A')#in the update only
    staff_since = DateField('Staff Since', format='%Y-%m-%d')#in the update only
    address = StringField('Address', [validators.DataRequired(),validators.length(min=1, max=150)])
    departments = RadioField('Departments', choices=[('A', 'Administrators'), ('P', 'Products'), ('R', 'Rewards'),('E', 'Events'),('S', 'After Sales Service')], default='A')
    remarks = TextAreaField('Remarks', [validators.Optional()])

class CreateCustomerForm(Form):
    first_name = StringField('First Name', [validators.length(min=1, max=150), validators.DataRequired()])
    last_name = StringField('Last Name', [validators.length(min=1, max=150), validators.DataRequired()])
    email = EmailField('Email', [validators.Email(), validators.DataRequired()]) #in update from profile
    phone_number = TelField('Phone Number',[validators.DataRequired(),validators.length(min=7, max=15)])
    birthday = DateField('Birthday', format='%Y-%m-%d') #in update from profile
    occupation = StringField('Occupation', [validators.DataRequired(),validators.length(min=1, max=150)]) #in update from profile
    date_joined = DateField('Date Joined', format='%Y-%m-%d')
    address = TextAreaField('Mailing Address', [validators.Length(max=200), validators.DataRequired()])#in update from profile
    remarks = TextAreaField('Remarks', [validators.Optional()])
