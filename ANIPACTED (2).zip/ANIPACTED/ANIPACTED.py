from flask import Flask, render_template, request, redirect, url_for
from Forms import CreateStaffForm, CreateCustomerForm
import shelve, Staff, Customer

ANIPACTED = Flask(__name__)


@ANIPACTED.route('/')
def cs_home():
    return render_template('homeCS.html')


@ANIPACTED.route('/retrieveCS.html')
def retrieve_cs():
    customers_dict = {}
    db = shelve.open('customer.db', 'r')
    customers_dict = db['Customers']
    db.close()

    customers_list = []

    for key in customers_dict:
        customer = customers_dict.get(key)
        customers_list.append(customer)

    return render_template('retrieveCS.html', count=len(customers_list), customers_list=customers_list)


@ANIPACTED.route('/retrieveSTF.html')
def retrieve_stf():
    staff_dict = {}
    db = shelve.open('staff.db', 'r')
    staff_dict = db['STF']
    db.close()

    staff_list = []
    for key in staff_dict:
        staff = staff_dict.get(key)
        staff_list.append(staff)

    return render_template('retrieveSTF.html', count=len(staff_list), staff_list=staff_list)


@ANIPACTED.route('/updateSTF.html/<int:id>/', methods=['GET', 'POST'])
def update_stf(id):
    update_staff_form = CreateStaffForm(request.form)
    if request.method == 'POST' and update_staff_form.validate():
        staff_dict = {}
        db = shelve.open('staff.db', 'w')
        staff_dict = db['STF']

        staff = staff_dict.get(id)
        staff.set_first_name(update_staff_form.first_name.data)
        staff.set_last_name(update_staff_form.last_name.data)
        staff.set_email(update_staff_form.email.data)
        staff.set_phone_number(update_staff_form.phone_number.data)
        staff.set_staff_status(update_staff_form.staff_status.data)
        staff.set_staff_since(update_staff_form.staff_since.data)
        staff.set_address(update_staff_form.address.data)
        staff.set_departments(update_staff_form.departments.data)
        staff.set_remarks(update_staff_form.remarks.data)

        db['STF'] = staff_dict
        db.close()

        return redirect(url_for('retrieve_stf'))
    else:
        staff_dict = {}
        db = shelve.open('staff.db', 'r')
        staff_dict = db['STF']
        db.close()

        staff = staff_dict.get(id)
        update_staff_form.first_name.data = staff.get_first_name()
        update_staff_form.last_name.data = staff.get_last_name() 
        update_staff_form.email.data = staff.get_email()
        update_staff_form.phone_number.data = staff.get_phone_number()
        update_staff_form.staff_status.data = staff.get_staff_status()
        update_staff_form.staff_since.data = staff.get_staff_since()
        update_staff_form.address.data = staff.get_address()
        update_staff_form.departments.data = staff.get_departments()
        update_staff_form.remarks.data = staff.set_remarks()

        return render_template('updateSTF.html', form=update_staff_form)


@ANIPACTED.route('/updateCS.html/<int:id>/', methods=['GET', 'POST'])
def update_cs(id):
    update_customer_form = CreateCustomerForm(request.form)
    if request.method == 'POST' and update_customer_form.validate():
        customers_dict = {}
        db = shelve.open('customer.db', 'w')
        customers_dict = db['Customers']

        customer = customers_dict.get(id)
        customer.set_first_name(update_customer_form.first_name.data)
        customer.set_last_name(update_customer_form.last_name.data)
        customer.set_email(update_customer_form.email.data)
        customer.set_phone_number(update_customer_form.phone_number.data)
        customer.set_birthday(update_customer_form.birthday.data)
        customer.set_occupation(update_customer_form.occupation.data)
        customer.set_address(update_customer_form.address.data)
        customer.set_date_joined(update_customer_form.date_joined.data)
        customer.set_remarks(update_customer_form.remarks.data)

        db['Customers'] = customers_dict
        db.close()

        return redirect(url_for('retrieve_cs'))
    else:
        customers_dict = {}
        db = shelve.open('customer.db', 'r')
        customers_dict = db['Customers']
        db.close()

        customer = customers_dict.get(id)
        update_customer_form.first_name.data = customer.get_first_name()
        update_customer_form.last_name.data = customer.get_last_name()
        update_customer_form.email.data = customer.get_email()
        update_customer_form.phone_number.data = customer.get_phone_number()
        update_customer_form.birthday.data = customer.get_birthday()
        update_customer_form.occupation.data = customer.get_occupation()
        update_customer_form.address.data = customer.get_address()
        update_customer_form.date_joined.data = customer.get_date_joined()
        update_customer_form.remarks.data = customer.get_remarks()

        return render_template('updateCS.html', form=update_customer_form)


@ANIPACTED.route('/deleteSTF/<int:id>', methods=['POST'])
def delete_stf(id):
    staff_dict = {}
    db = shelve.open('staff.db', 'w')
    staff_dict = db['STF']

    staff_dict.pop(id)

    db['STF'] = staff_dict
    db.close()

    return redirect(url_for('retrieve_stf'))


@ANIPACTED.route('/deleteCS/<int:id>', methods=['POST'])
def delete_cs(id):
    customers_dict = {}
    db = shelve.open('customer.db', 'w')
    customers_dict = db['Customers']
    customers_dict.pop(id)

    db['Customers'] = customers_dict
    db.close()

    return redirect(url_for('retrieve_cs'))


@ANIPACTED.route('/createSTF.html', methods=['GET', 'POST'])
def create_staff():
    create_staff_form = CreateStaffForm(request.form)
    if request.method == 'POST' and create_staff_form.validate():
        staff_dict = {}
        db = shelve.open('staff.db', 'c')

        try:
            staff_dict = db['Staff']
        except:
            print("Error in retrieving Users from user.db.")

        staff = Staff.Staff(create_staff_form.first_name.data, create_staff_form.last_name.data, create_staff_form.email.data, create_staff_form.phone_number.data, create_staff_form.staff_status.data, create_staff_form.staff_since.data, create_staff_form.remarks.data)
        staff_dict[staff.get_user_id()] = staff
        db['Staff'] = staff_dict

        db.close()

        return redirect(url_for('retrieve_stf'))
    return render_template('createSTF.html', form=create_staff_form)


@ANIPACTED.route('/LoginCS.html')
def cs_login():
    return render_template('LoginCS.html')


@ANIPACTED.route('/createCS.html')
def create_cs():
    create_customer_form = CreateCustomerForm(request.form)
    if request.method == 'POST' and create_customer_form.validate():
        customers_dict = {}
        db = shelve.open('customer.db', 'c')

        try:
            customers_dict = db['Customers']
        except:
            print("Error in retrieving Customers from customer.db.")

        customer = Customer.Customer(create_customer_form.first_name.data, create_customer_form.last_name.data,
                                     create_customer_form.remarks.data, create_customer_form.email.data,
                                     create_customer_form.date_joined.data, create_customer_form.address.data, create_customer_form.remarks.data)
##        customers_dict[customer.get_customer_id()] = customer
        customers_dict[customer.get_user_id()] = customer
        db['Customers'] = customers_dict

        db.close()

        return redirect(url_for('retrieve_cs'))
    return render_template('createCS.html', form=create_customer_form)


@ANIPACTED.route('/homeSTF.html')
def stf_home():
    return render_template('homeSTF.html')


@ANIPACTED.route('/LoginSTF.html')
def stf_login():
    return render_template('LoginSTF.html')

if __name__ == '__main__':
    ANIPACTED.run(debug=True)
